import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useApi, useApiMutation } from '../../hooks/useApi'
import { quizService } from '../../services/quizService'
import Card from '../../components/ui/Card'
import Button from '../../components/ui/Button'
import Input from '../../components/ui/Input'
import Badge from '../../components/ui/Badge'
import LoadingSpinner from '../../components/common/LoadingSpinner'
import { toast } from 'sonner'
import {
  PlusIcon,
  PencilIcon,
  TrashIcon,
  EyeIcon,
  ChartBarIcon,
  MagnifyingGlassIcon,
  ClipboardDocumentListIcon
} from '@heroicons/react/24/outline'
import { formatDateTime } from '../../utils/helpers'

const ManageQuizzes = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [showCreateModal, setShowCreateModal] = useState(false)
  const navigate = useNavigate(); // <-- add this line


  const { data: quizzes, loading, refetch } = useApi(() => quizService.getAllQuizzes())
  const { mutate: deleteQuiz } = useApiMutation(quizService.deleteQuiz)

  const quizzesArray = Array.isArray(quizzes) ? quizzes : [];
  const filteredQuizzes = quizzesArray.filter(quiz =>
    quiz.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    quiz.category?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDeleteQuiz = async (quizId, quizTitle) => {
    if (window.confirm(`Are you sure you want to delete "${quizTitle}"? This will also delete all associated questions and results.`)) {
      const result = await deleteQuiz(quizId)
      if (result.success) {
        toast.success('Quiz deleted successfully')
        refetch()
      }
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Quiz Management</h1>
          <p className="text-gray-600 mt-2">Create and manage quiz content</p>
        </div>
        <Button
          icon={PlusIcon}
          onClick={() => setShowCreateModal(true)}
          className="mt-4 sm:mt-0"
        >
          Create Quiz
        </Button>
      </div>

      {/* Search */}
      <Card className="mb-8">
        <Input
          placeholder="Search quizzes by title or category..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          icon={MagnifyingGlassIcon}
        />
      </Card>

      {/* Quizzes Grid */}
      {loading ? (
        <div className="flex justify-center py-8">
          <LoadingSpinner />
        </div>
      ) : filteredQuizzes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredQuizzes.map((quiz) => (
            <Card key={quiz._id} className="hover:shadow-lg transition-shadow">
              <div className="flex flex-col h-full">
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">
                      {quiz.title}
                    </h3>
                    <Badge variant={quiz.isPublished ? 'success' : 'warning'} size="sm">
                      {quiz.isPublished ? 'Published' : 'Draft'}
                    </Badge>
                  </div>

                  <p className="text-gray-600 mb-4 line-clamp-2">
                    {quiz.description}
                  </p>

                  <div className="space-y-2 text-sm text-gray-600 mb-4">
                    <div className="flex justify-between">
                      <span>Category:</span>
                      <span className="font-medium">{quiz.category?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Questions:</span>
                      <span className="font-medium">{quiz.questions?.length || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Time Limit:</span>
                      <span className="font-medium">{quiz.timeLimit} min</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Created:</span>
                      <span className="font-medium">{formatDateTime(quiz.createdAt)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 pt-4 border-t border-gray-100">
                  <Link to={`/quiz/${quiz._id}`}>
                    <Button variant="outline" size="sm" icon={EyeIcon}>
                      View
                    </Button>
                  </Link>
                  <Button variant="outline" size="sm" icon={PencilIcon}>
                    Edit
                  </Button>
                  <Link to={`/admin/quiz/${quiz._id}/analytics`}>
                    <Button variant="outline" size="sm" icon={ChartBarIcon}>
                      Analytics
                    </Button>
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    icon={TrashIcon}
                    onClick={() => handleDeleteQuiz(quiz._id, quiz.title)}
                    className="text-red-600 hover:text-red-700"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="text-center py-12">
          <ClipboardDocumentListIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No quizzes found</h3>
          <p className="text-gray-600 mb-4">
            {searchTerm ? 'No quizzes match your search.' : 'Get started by creating your first quiz.'}
          </p>
          <Button icon={PlusIcon} onClick={() => setShowCreateModal(true)}>
            Create Quiz
          </Button>
        </Card>
      )}

      {/* Create Quiz Modal - This would be a separate component in a real app */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-md w-full">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Quiz</h3>
            <p className="text-gray-600 mb-6">
              This will open the quiz creation form where you can add title, description, questions, and settings.
            </p>
            <div className="flex space-x-4">
              <Button
                variant="outline"
                onClick={() => setShowCreateModal(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                className="flex-1"
                onClick={() => {
                  setShowCreateModal(false);
                  navigate('/admin/questions');
                }}
              >
                Continue
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  )
}

export default ManageQuizzes