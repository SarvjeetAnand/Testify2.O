import { useState, useEffect } from 'react'
import { ClockIcon } from '@heroicons/react/24/outline'
import { formatTime } from '../../utils/helpers'

const QuizTimer = ({ initialTime, onTimeUp, isActive = true }) => {
  const [timeLeft, setTimeLeft] = useState(initialTime)

  useEffect(() => {
    if (!isActive || timeLeft <= 0) return

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          onTimeUp()
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [timeLeft, isActive, onTimeUp])

  const percentage = (timeLeft / initialTime) * 100
  const isWarning = percentage <= 25
  const isCritical = percentage <= 10

  return (
    <div className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
      isCritical ? 'bg-red-100 text-red-800' : 
      isWarning ? 'bg-yellow-100 text-yellow-800' : 
      'bg-blue-100 text-blue-800'
    }`}>
      <ClockIcon className="w-5 h-5" />
      <span className="font-mono font-semibold">
        {formatTime(timeLeft)}
      </span>
    </div>
  )
}

export default QuizTimer