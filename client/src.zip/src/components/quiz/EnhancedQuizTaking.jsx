// components/quiz/EnhancedQuizTaking.jsx
import { useState, useEffect, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useApi, useApiMutation } from '../../hooks/useApi'
import { quizService } from '../../services/quiz'
import QuizTimer from './QuizTimer'
import QuestionCard from './QuestionCard'
import Button from '../ui/Button'
import Card from '../ui/Card'
import { toast } from 'sonner'

const EnhancedQuizTaking = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState({})
  const [attemptId, setAttemptId] = useState(null)
  const [autoSaveEnabled, setAutoSaveEnabled] = useState(true)

  const { data: quiz, loading } = useApi(() => quizService.getQuizById(id), [id])
  const { mutate: startAttempt } = useApiMutation(quizService.startQuizAttempt)
  const { mutate: saveAnswer } = useApiMutation(quizService.saveAnswer)
  const { mutate: submitAttempt } = useApiMutation(quizService.submitQuizAttempt)

  // Auto-save functionality
  const autoSave = useCallback(async (questionId, answer) => {
    if (!autoSaveEnabled || !attemptId) return
    
    try {
      await saveAnswer(attemptId, {
        questionId,
        selectedOption: answer,
        timeSpent: 0 // You could track individual question time
      })
    } catch (error) {
      console.error('Auto-save failed:', error)
    }
  }, [attemptId, autoSaveEnabled, saveAnswer])

  // Handle answer changes with auto-save
  const handleAnswerChange = useCallback((questionId, answer) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }))
    
    // Auto-save after a delay
    setTimeout(() => autoSave(questionId, answer), 1000)
  }, [autoSave])

  // Initialize quiz attempt
  useEffect(() => {
    const initializeAttempt = async () => {
      if (quiz && !attemptId) {
        const result = await startAttempt(id)
        if (result.success) {
          setAttemptId(result.data._id)
          // Load existing answers if resuming
          if (result.data.answers) {
            const existingAnswers = {}
            result.data.answers.forEach(answer => {
              if (answer.selectedOption !== null) {
                existingAnswers[answer.question] = answer.selectedOption
              }
            })
            setAnswers(existingAnswers)
          }
        }
      }
    }
    
    initializeAttempt()
  }, [quiz, id, attemptId, startAttempt])

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === 'ArrowRight' && currentQuestion < (quiz?.questions?.length || 0) - 1) {
        setCurrentQuestion(prev => prev + 1)
      } else if (e.key === 'ArrowLeft' && currentQuestion > 0) {
        setCurrentQuestion(prev => prev - 1)
      }
    }

    window.addEventListener('keydown', handleKeyPress)
    return () => window.removeEventListener('keydown', handleKeyPress)
  }, [currentQuestion, quiz])

  const handleSubmitQuiz = async () => {
    if (!attemptId) return
    
    const result = await submitAttempt(attemptId)
    if (result.success) {
      navigate(`/quiz/${id}/results`, { 
        state: { attemptId: result.data._id }
      })
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <LoadingSpinner size="lg" />
      </div>
    )
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Enhanced header with progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900">{quiz?.title}</h1>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">Auto-save:</span>
              <button
                onClick={() => setAutoSaveEnabled(!autoSaveEnabled)}
                className={`w-8 h-4 rounded-full ${autoSaveEnabled ? 'bg-green-500' : 'bg-gray-300'} relative transition-colors`}
              >
                <div className={`w-3 h-3 bg-white rounded-full absolute top-0.5 transition-transform ${autoSaveEnabled ? 'translate-x-4' : 'translate-x-0.5'}`} />
              </button>
            </div>
            <QuizTimer
              initialTime={quiz?.timeLimit * 60}
              onTimeUp={handleSubmitQuiz}
              isActive={true}
            />
          </div>
        </div>
        
        {/* Enhanced progress bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-gray-600">
            <span>Question {currentQuestion + 1} of {quiz?.questions?.length}</span>
            <span>{Object.keys(answers).length} answered</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / (quiz?.questions?.length || 1)) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Rest of the component... */}
      {quiz?.questions?.[currentQuestion] && (
        <QuestionCard
          question={quiz.questions[currentQuestion]}
          selectedAnswer={answers[quiz.questions[currentQuestion]._id]}
          onAnswerChange={(answer) => handleAnswerChange(quiz.questions[currentQuestion]._id, answer)}
          questionNumber={currentQuestion + 1}
        />
      )}
    </div>
  )
}

export default EnhancedQuizTaking