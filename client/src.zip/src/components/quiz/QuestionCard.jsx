import Card from '../ui/Card'

const QuestionCard = ({ question, selectedAnswer, onAnswerChange, questionNumber }) => {
  return (
    <Card>
      <div className="mb-6">
        <div className="flex items-start justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900 flex-1">
            <span className="text-blue-600">Q{questionNumber}.</span> {question.questionText}
          </h2>
          <div className="ml-4 text-sm text-gray-500 whitespace-nowrap">
            {question.points || 1} {question.points === 1 ? 'point' : 'points'}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {question.options.map((option, index) => (
          <label
            key={index}
            className={`flex items-center p-4 rounded-lg border-2 cursor-pointer transition-all hover:bg-gray-50 ${
              selectedAnswer === index
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200'
            }`}
          >
            <input
              type="radio"
              name={`question-${question._id}`}
              value={index}
              checked={selectedAnswer === index}
              onChange={() => onAnswerChange(index)}
              className="sr-only"
            />
            <div className={`w-5 h-5 rounded-full border-2 mr-3 flex items-center justify-center ${
              selectedAnswer === index
                ? 'border-blue-500 bg-blue-500'
                : 'border-gray-300'
            }`}>
              {selectedAnswer === index && (
                <div className="w-2 h-2 bg-white rounded-full" />
              )}
            </div>
            <span className="text-gray-900 flex-1">{option}</span>
          </label>
        ))}
      </div>
    </Card>
  )
}

export default QuestionCard