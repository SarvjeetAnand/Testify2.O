// src/components/admin/BulkQuestionUpload.jsx
import React, { useState } from 'react';
import { 
  CloudArrowUpIcon, 
  DocumentTextIcon, 
  CheckCircleIcon, 
  XCircleIcon,
  ExclamationTriangleIcon 
} from '@heroicons/react/24/outline';
import { adminService } from '../../services/adminService';
import toast from 'react-hot-toast';

const BulkQuestionUpload = ({ quizId, onSuccess }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [preview, setPreview] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const [uploadResult, setUploadResult] = useState(null);

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file && file.type === 'application/pdf') {
      setSelectedFile(file);
      setPreview(null);
      setUploadResult(null);
    } else {
      toast.error('Please select a PDF file');
    }
  };

  const handlePreview = async () => {
    if (!selectedFile) {
      toast.error('Please select a PDF file first');
      return;
    }

    setIsUploading(true);
    try {
      const result = await adminService.previewQuestionsFromPDF(selectedFile);
      if (result.success) {
        setPreview(result.data);
        setShowPreview(true);
        toast.success(`Found ${result.data.totalQuestions} questions in PDF`);
      } else {
        toast.error(result.message || 'Failed to preview questions');
      }
    } catch (error) {
      toast.error('Error processing PDF file');
    } finally {
      setIsUploading(false);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile || !quizId) {
      toast.error('Please select a file and ensure quiz is selected');
      return;
    }

    setIsUploading(true);
    try {
      const result = await adminService.uploadQuestionsFromPDF(selectedFile, quizId);
      if (result.success) {
        setUploadResult(result.data);
        toast.success(`Successfully uploaded ${result.data.createdQuestions} questions!`);
        onSuccess && onSuccess();
        
        // Reset form
        setSelectedFile(null);
        setPreview(null);
        setShowPreview(false);
      } else {
        toast.error(result.message || 'Failed to upload questions');
      }
    } catch (error) {
      toast.error('Error uploading questions');
    } finally {
      setIsUploading(false);
    }
  };

  const resetForm = () => {
    setSelectedFile(null);
    setPreview(null);
    setShowPreview(false);
    setUploadResult(null);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Bulk Upload Questions from PDF
        </h3>
        <p className="text-sm text-gray-600">
          Upload a PDF file containing quiz questions. The system will automatically parse and extract questions.
        </p>
      </div>

      {/* PDF Format Instructions */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <h4 className="font-medium text-blue-900 mb-2">PDF Format Guidelines:</h4>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Questions should be numbered (Q1, Q2 or 1., 2.)</li>
          <li>• Options should be labeled (A), B), C), D) or a., b., c., d.)</li>
          <li>• Mark correct answers with * or [CORRECT] or ✓</li>
          <li>• Or include "Answer: A" or "Correct: B" after options</li>
        </ul>
      </div>

      {/* File Upload Area */}
      <div className="mb-6">
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
          <input
            type="file"
            accept=".pdf"
            onChange={handleFileSelect}
            className="hidden"
            id="pdf-upload"
          />
          <label htmlFor="pdf-upload" className="cursor-pointer">
            <CloudArrowUpIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-2">
              {selectedFile ? selectedFile.name : 'Click to select PDF file or drag and drop'}
            </p>
            <p className="text-xs text-gray-500">PDF files only, max 10MB</p>
          </label>
        </div>
      </div>

      {/* Action Buttons */}
      {selectedFile && (
        <div className="flex flex-wrap gap-3 mb-6">
          <button
            onClick={handlePreview}
            disabled={isUploading}
            className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 disabled:opacity-50"
          >
            <DocumentTextIcon className="h-4 w-4 mr-2" />
            {isUploading ? 'Processing...' : 'Preview Questions'}
          </button>
          
          {preview && (
            <button
              onClick={handleUpload}
              disabled={isUploading}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              <CloudArrowUpIcon className="h-4 w-4 mr-2" />
              {isUploading ? 'Uploading...' : `Upload ${preview.totalQuestions} Questions`}
            </button>
          )}
          
          <button
            onClick={resetForm}
            className="flex items-center px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
          >
            Reset
          </button>
        </div>
      )}

      {/* Preview Section */}
      {showPreview && preview && (
        <div className="mb-6">
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-medium text-gray-900">
                Preview: {preview.totalQuestions} Questions Found
              </h4>
              <button
                onClick={() => setShowPreview(!showPreview)}
                className="text-blue-600 hover:text-blue-700 text-sm"
              >
                {showPreview ? 'Hide' : 'Show'} Preview
              </button>
            </div>
            
            {preview.questions.length > 0 && (
              <div className="max-h-96 overflow-y-auto space-y-4">
                {preview.questions.slice(0, 3).map((question, index) => (
                  <div key={index} className="bg-white p-4 rounded border">
                    <h5 className="font-medium text-gray-900 mb-2">
                      Q{index + 1}: {question.questionText}
                    </h5>
                    <div className="space-y-1">
                      {question.options.map((option, optIndex) => (
                        <div
                          key={optIndex}
                          className={`text-sm p-2 rounded ${
                            optIndex === question.correctAnswer
                              ? 'bg-green-100 text-green-800 font-medium'
                              : 'bg-gray-50 text-gray-700'
                          }`}
                        >
                          {String.fromCharCode(65 + optIndex)}. {option}
                          {optIndex === question.correctAnswer && (
                            <CheckCircleIcon className="h-4 w-4 inline ml-2 text-green-600" />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                {preview.questions.length > 3 && (
                  <p className="text-sm text-gray-500 text-center">
                    ... and {preview.questions.length - 3} more questions
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Upload Result */}
      {uploadResult && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start">
            <CheckCircleIcon className="h-5 w-5 text-green-500 mt-0.5 mr-3" />
            <div>
              <h4 className="font-medium text-green-900">Upload Successful!</h4>
              <p className="text-sm text-green-800 mt-1">
                Created {uploadResult.createdQuestions} out of {uploadResult.totalExtracted} questions
              </p>
              {uploadResult.errors.length > 0 && (
                <div className="mt-2">
                  <p className="text-sm text-orange-800">
                    {uploadResult.errors.length} questions had errors:
                  </p>
                  <ul className="text-xs text-orange-700 mt-1 max-h-24 overflow-y-auto">
                    {uploadResult.errors.map((error, index) => (
                      <li key={index}>
                        Q{error.questionIndex}: {error.error}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Example Format */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-medium text-gray-900 mb-2">Example PDF Format:</h4>
        <div className="text-sm text-gray-700 font-mono bg-white p-3 rounded border">
          <div>Q1. What is the capital of France?</div>
          <div>A) London</div>
          <div>B) Paris *</div>
          <div>C) Berlin</div>
          <div>D) Madrid</div>
          <div className="mt-2">Q2. Which planet is closest to the sun?</div>
          <div>A) Mercury</div>
          <div>B) Venus</div>
          <div>C) Earth</div>
          <div>D) Mars</div>
          <div>Answer: A</div>
        </div>
      </div>
    </div>
  );
};

export default BulkQuestionUpload;