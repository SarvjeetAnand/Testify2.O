import React, { useState } from 'react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Select from '../ui/Select';
import { useApi } from '../../hooks/useApi';
import { useApiMutation } from '../../hooks/useApiMutation';
import { questionService } from '../../services/questionService';
import QuestionForm from './forms/QuestionForm';

const QuestionManagement = ({ categories = [] }) => {
  const { data: questions, loading, refetch } = useApi(() => questionService.getAllQuestions());
  const { mutate: deleteQuestion } = useApiMutation(questionService.deleteQuestion);
  const [searchTerm, setSearchTerm] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editData, setEditData] = useState(null);

  const questionsArray = Array.isArray(questions) ? questions : [];
  const filteredQuestions = questionsArray.filter(
    (q) =>
      q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.category?.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this question?')) {
      await deleteQuestion(id);
      refetch();
    }
  };

  const handleEdit = (question) => {
    setEditData(question);
    setShowForm(true);
  };

  const handleCreate = () => {
    setEditData(null);
    setShowForm(true);
  };

  const handleFormSubmit = async (data) => {
    if (editData) {
      await questionService.updateQuestion(editData._id, data);
    } else {
      await questionService.createQuestion(data);
    }
    setShowForm(false);
    setEditData(null);
    refetch();
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Question Management</h1>
          <p className="text-gray-600 mt-2">Create and manage quiz questions</p>
        </div>
        <Button onClick={handleCreate} className="mt-4 sm:mt-0">
          Create Question
        </Button>
      </div>

      <Card className="mb-8">
        <Input
          placeholder="Search questions by text or category..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </Card>

      {loading ? (
        <div className="flex justify-center py-8">Loading...</div>
      ) : filteredQuestions.length > 0 ? (
        <div className="space-y-4">
          {filteredQuestions.map((q) => (
            <Card key={q._id} className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="font-semibold">{q.question}</div>
                <div className="text-sm text-gray-500">
                  Category: {q.category?.name || 'Uncategorized'}
                </div>
                <div className="text-sm text-gray-500">
                  Options: {q.options.map((opt, idx) => (
                    <span key={idx} className={opt.isCorrect ? 'font-bold text-green-700' : ''}>
                      {opt.text}{idx < q.options.length - 1 ? ', ' : ''}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => handleEdit(q)}>
                  Edit
                </Button>
                <Button size="sm" variant="ghost" className="text-red-600" onClick={() => handleDelete(q._id)}>
                  Delete
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="text-center py-12">
          <h3 className="text-lg font-medium text-gray-900 mb-2">No questions found</h3>
          <p className="text-gray-600 mb-4">
            {searchTerm ? 'No questions match your search.' : 'Get started by creating your first question.'}
          </p>
          <Button onClick={handleCreate}>Create Question</Button>
        </Card>
      )}

      {showForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-lg w-full">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              {editData ? 'Edit Question' : 'Create New Question'}
            </h3>
            <QuestionForm
              initialData={editData}
              categories={categories}
              onSubmit={handleFormSubmit}
              onCancel={() => {
                setShowForm(false);
                setEditData(null);
              }}
            />
          </Card>
        </div>
      )}
    </div>
  );
};

export default QuestionManagement;