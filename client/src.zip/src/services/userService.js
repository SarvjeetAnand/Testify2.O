import api from './api'; // Make sure you have an api.js that exports your axios instance

export const userService = {
  getProfile: async () => {
    try {
      const res = await api.get('/user/profile');
      return { success: true, data: res.data };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || 'Error fetching profile' };
    }
  },

  updateProfile: async (profileData) => {
    try {
      const res = await api.put('/user/profile', profileData);
      return { success: true, data: res.data };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || 'Error updating profile' };
    }
  },
};